const express = require("express");
const router = express.Router();
const { protect, authorize } = require("../middleware/auth");
const { uploadCourseContent } = require("../middleware/upload");
const {
  createCourse,
  getCourses,
  getCourse,
  updateCourse,
  deleteCourse,
  getCoursesBySubject,
  getSubjects,
  getCourseStats,
} = require("../controllers/courseController");

// Protect all routes
router.use(protect);

// Public routes (all authenticated users)
router.get("/", getCourses);
router.get("/subjects/list", getSubjects);
router.get("/subject/:subject", getCoursesBySubject);
router.get("/:id", getCourse);

// Admin & Teacher only routes
router.post(
  "/",
  authorize("admin", "teacher"),
  uploadCourseContent("content"),
  createCourse
);

router.put(
  "/:id",
  authorize("admin", "teacher"),
  uploadCourseContent("content"),
  updateCourse
);

router.delete("/:id", authorize("admin", "teacher"), deleteCourse);

router.get(
  "/stats/overview",
  authorize("admin", "teacher"),
  getCourseStats
);

module.exports = router;

